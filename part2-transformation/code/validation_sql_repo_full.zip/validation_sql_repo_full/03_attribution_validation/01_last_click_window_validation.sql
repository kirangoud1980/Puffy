-- Validate last-click attribution window boundaries
SELECT o.transaction_id, o.order_ts, t.session_start_ts
FROM analytics.attribution_last_click at
JOIN analytics.orders o ON at.transaction_id = o.transaction_id
JOIN analytics.touches t ON at.last_touch.session_id = t.session_id
WHERE t.session_start_ts < TIMESTAMP_SUB(o.order_ts, INTERVAL 7 DAY)
   OR t.session_start_ts > o.order_ts;
