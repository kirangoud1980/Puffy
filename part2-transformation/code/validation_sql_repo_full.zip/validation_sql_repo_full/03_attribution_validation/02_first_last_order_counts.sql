-- Matching order counts across attribution models
SELECT
 (SELECT COUNT(*) FROM analytics.orders) AS total_orders,
 (SELECT COUNT(*) FROM analytics.attribution_first_click) AS first_click_count,
 (SELECT COUNT(*) FROM analytics.attribution_last_click) AS last_click_count;
