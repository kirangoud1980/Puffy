-- Session Coverage Check
SELECT COUNT(*) AS total_events,
       SUM(CASE WHEN session_id IS NOT NULL THEN 1 ELSE 0 END) AS mapped_events,
       SAFE_DIVIDE(SUM(CASE WHEN session_id IS NOT NULL THEN 1 ELSE 0 END), COUNT(*)) AS session_coverage
FROM analytics.session_events;
