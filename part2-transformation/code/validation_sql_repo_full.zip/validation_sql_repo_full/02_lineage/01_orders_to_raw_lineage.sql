-- Lineage check: Ensure each order maps to raw checkout event
SELECT a.transaction_id
FROM analytics.orders a
LEFT JOIN stg.events_clean s
  ON a.transaction_id = s.transaction_id AND s.event_name='checkout_completed'
WHERE s.transaction_id IS NULL;
