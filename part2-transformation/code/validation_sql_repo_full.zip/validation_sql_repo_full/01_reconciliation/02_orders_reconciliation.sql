-- Orders Reconciliation Check
WITH stg_revenue AS (
  SELECT DATE(event_ts) AS evt_date,
         SUM(CAST(SAFE_JSON_EXTRACT_SCALAR(event_data,'$.revenue') AS NUMERIC)) AS raw_revenue
  FROM stg.events_clean
  WHERE event_name='checkout_completed'
  GROUP BY evt_date
),
orders_revenue AS (
  SELECT DATE(order_ts) AS order_date,
         SUM(revenue) AS orders_revenue
  FROM analytics.orders
  GROUP BY order_date
)
SELECT r.evt_date, r.raw_revenue, o.orders_revenue,
       SAFE_DIVIDE(o.orders_revenue, r.raw_revenue) AS pct
FROM stg_revenue r
LEFT JOIN orders_revenue o ON r.evt_date = o.order_date;
