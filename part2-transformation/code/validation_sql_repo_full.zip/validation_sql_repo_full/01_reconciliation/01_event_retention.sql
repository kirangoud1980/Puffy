-- Event Retention Check
WITH raw_counts AS (
  SELECT DATE(timestamp) AS event_date, event_name, COUNT(*) AS raw_count
  FROM raw.events
  GROUP BY event_date, event_name
),
stg_counts AS (
  SELECT DATE(event_ts) AS event_date, event_name, COUNT(*) AS stg_count
  FROM stg.events_clean
  GROUP BY event_date, event_name
)
SELECT r.event_date, r.event_name, r.raw_count, s.stg_count,
       SAFE_DIVIDE(s.stg_count, r.raw_count) AS retention_ratio
FROM raw_counts r
LEFT JOIN stg_counts s
  ON r.event_date = s.event_date AND r.event_name = s.event_name;
