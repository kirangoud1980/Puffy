-- Identify corrupt items in order payload
SELECT *
FROM analytics.orders
WHERE EXISTS (
  SELECT 1
  FROM UNNEST(items) it
  WHERE it.item_id IS NULL OR it.item_price IS NULL
);
