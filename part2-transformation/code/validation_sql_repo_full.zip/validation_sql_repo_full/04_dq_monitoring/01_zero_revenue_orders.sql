-- Zero-revenue orders
SELECT *
FROM analytics.orders
WHERE revenue IS NULL OR revenue = 0;
