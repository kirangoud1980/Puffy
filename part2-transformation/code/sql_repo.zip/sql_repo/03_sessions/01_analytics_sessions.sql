-- analytics.sessions
-- Sessionize events per client_id using 30-minute inactivity window and referrer/device change
CREATE OR REPLACE TABLE analytics.sessions AS
WITH events AS (
  SELECT client_id, event_ts, event_name, page_url, referrer_host, device_type, user_agent,
         ROW_NUMBER() OVER (PARTITION BY client_id ORDER BY event_ts) AS rn
  FROM stg.events_clean
  WHERE client_id IS NOT NULL
),
lagged AS (
  SELECT e.*,
         LAG(event_ts) OVER (PARTITION BY client_id ORDER BY event_ts) AS prev_event_ts,
         LAG(referrer_host) OVER (PARTITION BY client_id ORDER BY event_ts) AS prev_referrer,
         LAG(device_type) OVER (PARTITION BY client_id ORDER BY event_ts) AS prev_device
  FROM events e
),
session_boundaries AS (
  SELECT *, CASE
    WHEN prev_event_ts IS NULL THEN 1
    WHEN TIMESTAMP_DIFF(event_ts, prev_event_ts, MINUTE) > 30 THEN 1
    WHEN prev_referrer IS NULL OR referrer_host IS NULL THEN 0
    WHEN referrer_host != prev_referrer THEN 1
    WHEN device_type != prev_device THEN 1
    ELSE 0 END AS is_new_session
  FROM lagged
),
sessionized AS (
  SELECT *, SUM(is_new_session) OVER (PARTITION BY client_id ORDER BY event_ts ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS session_seq
  FROM session_boundaries
),
session_ids AS (
  SELECT client_id, event_ts, session_seq,
         MIN(event_ts) OVER (PARTITION BY client_id, session_seq) AS session_start_ts,
         MAX(event_ts) OVER (PARTITION BY client_id, session_seq) AS session_end_ts,
         COUNTIF(event_name='page_viewed') OVER (PARTITION BY client_id, session_seq) AS pages_in_session,
         COUNT(*) OVER (PARTITION BY client_id, session_seq) AS events_in_session,
         ANY_VALUE(referrer_host) OVER (PARTITION BY client_id, session_seq) AS session_referrer,
         ANY_VALUE(device_type) OVER (PARTITION BY client_id, session_seq) AS session_device
  FROM sessionized
)
SELECT client_id,
       CONCAT(client_id, '_', FORMAT_TIMESTAMP('%Y%m%d%H%M%S', session_start_ts)) AS session_id,
       session_start_ts, session_end_ts,
       TIMESTAMP_DIFF(session_end_ts, session_start_ts, SECOND) AS session_duration_seconds,
       pages_in_session, events_in_session, session_referrer, session_device
FROM session_ids
GROUP BY client_id, session_seq, session_start_ts, session_end_ts, pages_in_session, events_in_session, session_referrer, session_device;
