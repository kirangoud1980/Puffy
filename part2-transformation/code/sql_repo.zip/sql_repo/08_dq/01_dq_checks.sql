-- DQ Checks (examples)
-- 1) Files missing required columns
SELECT file_name FROM dataset.__file_manifest WHERE NOT ('client_id' IN columns AND 'referrer' IN columns);

-- 2) Orders with zero revenue
SELECT * FROM analytics.orders WHERE revenue IS NULL OR revenue = 0;

-- 3) Orders with corrupt items
SELECT * FROM analytics.orders WHERE EXISTS(SELECT 1 FROM UNNEST(items) it WHERE it.item_id IS NULL OR it.item_price IS NULL);
