# Analytics SQL Repository

This repository contains SQL scripts to transform raw event data into analytics-ready tables for sessionization, item explosion, orders, and attribution (first-click & last-click) with a 7-day lookback.

## Folder structure
- 01_staging/ : staging SQL to normalize raw events and parse JSON
- 02_items/   : explode commerce items into row-per-item
- 03_sessions/: sessionization scripts
- 04_session_events/: map events to sessions
- 05_orders/  : consolidate orders table
- 06_attribution/: touches and attribution views (last & first click)
- 07_views/   : channel performance & engagement views
- 08_dq/      : data quality check examples

## How to use
1. Run scripts in order: staging -> items -> sessions -> session_events -> orders -> attribution -> views
2. Replace dataset names (`raw`, `stg`, `analytics`) with your own project.dataset if needed.
3. Ensure JSON functions used (SAFE_JSON_EXTRACT, JSON_QUERY_ARRAY) are supported by your SQL engine (BigQuery used as example).
4. Implement DQ checks to fail ingestion when critical issues occur.
