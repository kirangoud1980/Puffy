-- stg.events_clean
-- Normalize raw events, parse JSON, derive device and referrer_host, add DQ flags
CREATE OR REPLACE TABLE stg.events_clean AS
SELECT
  COALESCE(client_id, NULL) AS client_id,
  page_url,
  referrer,
  CASE
    WHEN referrer IS NULL THEN 'Direct'
    ELSE REGEXP_EXTRACT(referrer, r'^(?:https?://)?([^/]+)') END AS referrer_host,
  SAFE_CAST(timestamp AS TIMESTAMP) AS event_ts,
  event_name,
  event_data,
  user_agent,
  SAFE_JSON_EXTRACT_SCALAR(event_data, '$.transaction_id') AS transaction_id,
  SAFE_CAST(SAFE_JSON_EXTRACT_SCALAR(event_data, '$.revenue') AS NUMERIC) AS revenue,
  SAFE_JSON_EXTRACT(event_data, '$.items') AS items_json,
  CASE
    WHEN LOWER(user_agent) LIKE '%iphone%' OR LOWER(user_agent) LIKE '%android%' OR LOWER(user_agent) LIKE '%mobile%' THEN 'Mobile'
    WHEN LOWER(user_agent) LIKE '%ipad%' OR LOWER(user_agent) LIKE '%tablet%' THEN 'Tablet'
    ELSE 'Desktop' END AS device_type,
  (event_data IS NULL) AS dq_event_data_missing,
  (client_id IS NULL) AS dq_client_id_missing,
  (referrer IS NULL) AS dq_referrer_missing,
  CASE
    WHEN referrer IS NOT NULL AND REGEXP_CONTAINS(REGEXP_EXTRACT(referrer, r'^(?:https?://)?([^/]+)'), r'^source-[0-9a-f]{8}\.com$') THEN TRUE
    ELSE FALSE END AS dq_fake_referrer
FROM raw.events;
