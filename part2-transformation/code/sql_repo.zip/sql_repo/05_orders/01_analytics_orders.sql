-- analytics.orders
-- Consolidate checkout_completed events into orders, link to session when possible
CREATE OR REPLACE TABLE analytics.orders AS
SELECT
  o.transaction_id,
  o.client_id,
  o.event_ts AS order_ts,
  o.revenue,
  NULL AS currency,
  s.session_id,
  s.session_referrer AS session_referrer,
  s.session_device AS session_device,
  ARRAY_AGG(STRUCT(item.item_id, item.item_name, item.quantity, item.item_price)) AS items,
  o.event_data AS raw_event_data
FROM stg.events_clean o
LEFT JOIN analytics.session_events s
  ON o.client_id = s.client_id
  AND o.event_ts BETWEEN s.session_start_ts AND s.session_end_ts
WHERE o.event_name = 'checkout_completed'
GROUP BY transaction_id, o.client_id, o.event_ts, o.revenue, s.session_id, s.session_referrer, s.session_device, o.event_data;
