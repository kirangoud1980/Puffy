-- stg.event_items
-- Explode items array from commerce events into one row per item
CREATE OR REPLACE TABLE stg.event_items AS
WITH commerce AS (
  SELECT *
  FROM stg.events_clean
  WHERE event_name IN ('product_added_to_cart','checkout_started','checkout_completed')
)
SELECT
  e.client_id,
  e.event_ts,
  e.event_name,
  e.transaction_id,
  e.revenue,
  item_idx + 1 AS item_index,
  JSON_VALUE(item, '$.item_id') AS item_id,
  JSON_VALUE(item, '$.item_name') AS item_name,
  SAFE_CAST(JSON_VALUE(item, '$.item_price') AS NUMERIC) AS item_price,
  SAFE_CAST(JSON_VALUE(item, '$.quantity') AS INT64) AS quantity,
  e.device_type,
  e.referrer_host,
  e.page_url
FROM commerce e,
UNNEST(JSON_QUERY_ARRAY(e.items_json)) AS item WITH OFFSET AS item_idx;
