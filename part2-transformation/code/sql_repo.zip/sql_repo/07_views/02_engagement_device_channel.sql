-- analytics.engagement_device_channel
CREATE OR REPLACE VIEW analytics.engagement_device_channel AS
SELECT
  s.session_device AS device,
  COALESCE(at.last_touch.channel, 'Unknown') AS channel,
  COUNT(DISTINCT s.session_id) AS sessions,
  AVG(s.session_duration_seconds) AS avg_seconds,
  AVG(s.pages_in_session) AS avg_pages,
  SUM(CASE WHEN se.event_name='product_added_to_cart' THEN 1 ELSE 0 END) AS add_to_cart_events
FROM analytics.sessions s
LEFT JOIN analytics.session_events se ON se.session_id = s.session_id
LEFT JOIN analytics.attribution_last_click at ON at.client_id = s.client_id
GROUP BY device, channel;
