-- analytics.channel_performance_last_click (example)
CREATE OR REPLACE VIEW analytics.channel_performance_last_click AS
SELECT
  COALESCE(at.last_touch.channel, 'Unknown') AS channel,
  COUNT(DISTINCT o.transaction_id) AS purchases,
  SUM(o.revenue) AS revenue,
  AVG(o.revenue) AS avg_order_value
FROM analytics.orders o
LEFT JOIN analytics.attribution_last_click at ON o.transaction_id = at.transaction_id
GROUP BY channel
ORDER BY revenue DESC;
