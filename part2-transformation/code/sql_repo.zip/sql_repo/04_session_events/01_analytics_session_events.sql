-- analytics.session_events
-- Map raw events to sessions by time range join (left join; missing client_id will yield NULL session_id)
CREATE OR REPLACE TABLE analytics.session_events AS
SELECT
  se.* EXCEPT(_event_index),
  s.session_id,
  s.session_start_ts,
  s.session_end_ts,
  s.session_referrer AS session_referrer,
  s.session_device AS session_device
FROM stg.events_clean se
LEFT JOIN analytics.sessions s
  ON se.client_id = s.client_id
  AND se.event_ts BETWEEN s.session_start_ts AND s.session_end_ts;
