-- analytics.attribution_last_click
CREATE OR REPLACE VIEW analytics.attribution_last_click AS
WITH orders AS (
  SELECT transaction_id, client_id, order_ts, revenue FROM analytics.orders
),
touches AS (
  SELECT session_id, client_id, session_start_ts, channel, referrer_host FROM analytics.touches
)
SELECT
  o.transaction_id,
  o.client_id,
  o.order_ts,
  o.revenue,
  (SELECT AS STRUCT t.session_id, t.channel, t.referrer_host
   FROM touches t
   WHERE t.client_id = o.client_id
     AND t.session_start_ts BETWEEN TIMESTAMP_SUB(o.order_ts, INTERVAL 7 DAY) AND o.order_ts
   ORDER BY t.session_start_ts DESC
   LIMIT 1) AS last_touch
FROM orders o;
