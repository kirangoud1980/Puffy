-- analytics.touches
-- Define session-level touches for attribution
CREATE OR REPLACE TABLE analytics.touches AS
SELECT
  s.session_id,
  s.client_id,
  s.session_start_ts,
  s.session_end_ts,
  CASE
    WHEN REGEXP_CONTAINS(LOWER(s.session_referrer), r'(google|bing|yahoo|baidu)') THEN 'Organic Search'
    WHEN LOWER(s.session_referrer) LIKE '%google.com%' THEN 'Google'
    WHEN s.session_referrer = 'Direct' THEN 'Direct'
    ELSE s.session_referrer END AS channel,
  s.session_referrer AS referrer_host,
  s.session_device,
  s.pages_in_session
FROM analytics.sessions s
WHERE s.client_id IS NOT NULL;
